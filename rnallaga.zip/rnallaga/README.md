# ECE 39595 - Course Project
## Team: Shantanu Sinha (sinha93), Ronit Nallagatla (rnallaga)

---

- Parser code is contained in `step1/` directory. Code can be compiled using `make`. Parser produces `.out` files to be read by the VM.

- VM code can be found in `step2/` directory, and `make` command compiles it. VM takes in `.out` file and produces output to `stdout`.